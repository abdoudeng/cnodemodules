import { Fork } from "../types";
export default function (fork: Fork): void;
