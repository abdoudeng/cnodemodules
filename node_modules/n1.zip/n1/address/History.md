
1.0.3 / 2017-08-24
==================

**fixes**
  * [[`ed491c5`](http://github.com/node-modules/address/commit/ed491c5bd353118e4e4d384f47f13c3e1cfeb80e)] - fix: ignore wrong mac address on node 8.x (#10) (fengmk2 <<fengmk2@gmail.com>>)

1.0.2 / 2017-05-26
==================

  * fix: win32 get mac failed (#9)

1.0.1 / 2016-09-30
==================

  * test: remove 0.12
  * fix: search interface before family match
  * add contributors

1.0.0 / 2015-08-06
==================

 * chore: use npm scripts instead of Makefile
 * add benchmark

0.0.3 / 2013-11-04 
==================

  * get the first not local ip when interface not exists

0.0.2 / 2013-08-08 
==================

  * use networkInterface() to get mac fix #3

0.0.1 / 2013-07-31 
==================

  * ip(), ipv6(), mac(), dns() work on osx and linux now.
  * first commit
