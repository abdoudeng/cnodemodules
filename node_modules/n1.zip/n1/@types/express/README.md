# Installation
> `npm install --save @types/express`

# Summary
This package contains type definitions for Express (http://expressjs.com).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/express

Additional Details
 * Last updated: Tue, 22 Jan 2019 17:51:20 GMT
 * Dependencies: @types/body-parser, @types/serve-static, @types/express-serve-static-core
 * Global values: none

# Credits
These definitions were written by Boris Yankov <https://github.com/borisyankov>.
