# Installation
> `npm install --save @types/serve-static`

# Summary
This package contains type definitions for serve-static (https://github.com/expressjs/serve-static).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/serve-static

Additional Details
 * Last updated: Mon, 30 Apr 2018 16:18:31 GMT
 * Dependencies: express-serve-static-core, mime
 * Global values: none

# Credits
These definitions were written by Uros Smolnik <https://github.com/urossmolnik>, Linus Unnebäck <https://github.com/LinusU>.
