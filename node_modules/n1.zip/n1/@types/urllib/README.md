# Installation
> `npm install --save @types/urllib`

# Summary
This package contains type definitions for urllib ( https://github.com/node-modules/urllib ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/urllib

Additional Details
 * Last updated: Thu, 14 Feb 2019 00:21:07 GMT
 * Dependencies: @types/node
 * Global values: urllib

# Credits
These definitions were written by SoraYama <https://github.com/sorayama>.
