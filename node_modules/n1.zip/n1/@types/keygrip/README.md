# Installation
> `npm install --save @types/keygrip`

# Summary
This package contains type definitions for keygrip (https://github.com/crypto-utils/keygrip).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/keygrip

Additional Details
 * Last updated: Fri, 24 Mar 2017 15:49:53 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by jKey Lu <https://github.com/jkeylu>.
