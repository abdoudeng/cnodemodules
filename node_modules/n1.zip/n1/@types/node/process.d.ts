declare module "process" {
    export = process;
}
