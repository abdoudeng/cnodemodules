# Installation
> `npm install --save @types/koa`

# Summary
This package contains type definitions for Koa (http://koajs.com).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/koa

Additional Details
 * Last updated: Mon, 31 Dec 2018 18:46:29 GMT
 * Dependencies: @types/accepts, @types/cookies, @types/http-assert, @types/keygrip, @types/koa-compose, @types/node
 * Global values: none

# Credits
These definitions were written by DavidCai1993 <https://github.com/DavidCai1993>, jKey Lu <https://github.com/jkeylu>, Brice Bernard <https://github.com/brikou>.
