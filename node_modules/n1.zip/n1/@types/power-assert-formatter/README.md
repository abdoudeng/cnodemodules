# Installation
> `npm install --save @types/power-assert-formatter`

# Summary
This package contains type definitions for power-assert-formatter 1.4.1 (https://github.com/twada/power-assert-formatter).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/power-assert-formatter

Additional Details
 * Last updated: Sun, 25 Sep 2016 23:34:51 GMT
 * File structure: Global
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: powerAssertFormatter

# Credits
These definitions were written by vvakame <https://github.com/vvakame>.
