# Installation
> `npm install --save @types/power-assert`

# Summary
This package contains type definitions for power-assert (https://github.com/twada/power-assert).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/power-assert

Additional Details
 * Last updated: Tue, 10 Apr 2018 17:48:29 GMT
 * Dependencies: empower, power-assert-formatter
 * Global values: assert

# Credits
These definitions were written by vvakame <https://github.com/vvakame>.
