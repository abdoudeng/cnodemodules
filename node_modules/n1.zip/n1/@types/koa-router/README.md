# Installation
> `npm install --save @types/koa-router`

# Summary
This package contains type definitions for koa-router ( https://github.com/alexmingoia/koa-router#readme ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/koa-router

Additional Details
 * Last updated: Mon, 25 Feb 2019 23:34:53 GMT
 * Dependencies: @types/koa
 * Global values: none

# Credits
These definitions were written by Jerry Chin <https://github.com/hellopao>, Pavel Ivanov <https://github.com/schfkt>, JounQin <https://github.com/JounQin>, Romain Faust <https://github.com/romain-faust>, Guillaume Mayer <https://github.com/Guillaume-Mayer>, Andrea Gueugnaut <https://github.com/falinor>.
