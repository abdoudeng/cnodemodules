# Installation
> `npm install --save @types/empower`

# Summary
This package contains type definitions for empower 1.2.1 (https://github.com/twada/empower).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/empower

Additional Details
 * Last updated: Sun, 25 Sep 2016 23:34:50 GMT
 * File structure: UMD
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: empower

# Credits
These definitions were written by vvakame <https://github.com/vvakame>.
