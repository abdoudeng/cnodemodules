# Installation
> `npm install --save @types/ioredis`

# Summary
This package contains type definitions for ioredis ( https://github.com/luin/ioredis ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/ioredis

Additional Details
 * Last updated: Mon, 11 Mar 2019 18:39:07 GMT
 * Dependencies: @types/node
 * Global values: none

# Credits
These definitions were written by York Yao <https://github.com/plantain-00>, Christopher Eck <https://github.com/chrisleck>, Yoga Aliarham <https://github.com/aliarham11>, Ebrahim <https://github.com/br8h>, Shahar Mor <https://github.com/shaharmor>, Whemoon Jang <https://github.com/palindrom615>, Francis Gulotta <https://github.com/reconbot>, Dmitry Motovilov <https://github.com/funthing>, Oleg Repin <https://github.com/iamolegga>, Ting-Wai To <https://github.com/tingwai-to>, Alex Petty <https://github.com/pettyalex>.
