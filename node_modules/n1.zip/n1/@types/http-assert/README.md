# Installation
> `npm install --save @types/http-assert`

# Summary
This package contains type definitions for http-assert (https://github.com/jshttp/http-assert).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/http-assert

Additional Details
 * Last updated: Wed, 26 Dec 2018 06:43:30 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by jKey Lu <https://github.com/jkeylu>, Peter Squicciarini <https://github.com/stripedpajamas>.
