'use strict';
require('../register')('native-promise-only', {Promise: require('native-promise-only')})
